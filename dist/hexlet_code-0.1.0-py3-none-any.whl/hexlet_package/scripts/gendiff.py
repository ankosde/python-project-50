#!/usr/bin/env python3

from hexlet_package import user


def main():
    print(user.print_certificate()) 


if __name__ == '__main__':
    main()